using Microsoft.Playwright;

namespace UPTSite.Automation;

/// <summary>Navegación de la interfaz pública vigente del portal de la UPT.</summary>
public sealed class UptPortal(IPage page)
{
    /// <summary>Abre la dirección institucional y espera el documento inicial.</summary>
    public async Task OpenHomeAsync()
    {
        for (var attempt = 1; attempt <= 3; attempt++)
        {
            try
            {
                await page.GotoAsync("https://portal.upt.edu.pe/site/web/contenido/inicio", new() { WaitUntil = WaitUntilState.DOMContentLoaded });
                return;
            }
            catch (PlaywrightException error) when (attempt < 3 && error.Message.Contains("ERR_EMPTY_RESPONSE"))
            {
                Console.WriteLine($"Respuesta vacía del portal. Reintento de navegación {attempt + 1}/3.");
            }
        }
    }

    /// <summary>Despliega Pregrado y accede a Ingeniería de Sistemas.</summary>
    public async Task OpenSchoolAsync()
    {
        await page.GetByRole(AriaRole.Button, new() { Name = "Pregrado", Exact = true }).ClickAsync();
        await page.GetByRole(AriaRole.Link, new() { Name = "Escuela Profesional de Ingeniería de Sistemas", Exact = true }).ClickAsync();
        await page.WaitForURLAsync("**/contenido/ingenieria-sistemas");
    }

    /// <summary>Busca una carrera con el buscador público del portal.</summary>
    public async Task SearchAsync(string query)
    {
        await page.Locator("button.btn-header[data-bs-target=\"#buscadorModal\"]").ClickAsync();
        await page.Locator("#buscador-header-input").FillAsync(query);
        await page.Locator("#buscar").ClickAsync();
    }

    /// <summary>Accede al listado vigente de estudiantes desde los resultados de búsqueda.</summary>
    public async Task OpenStudentsAsync()
    {
        await SearchAsync("ingeniería de sistemas");
        await page.Locator("#buscador-header-results a[href$='/ingenieria-sistemas/estudiantes']").ClickAsync();
        await page.WaitForURLAsync("**/ingenieria-sistemas/estudiantes", new() { WaitUntil = WaitUntilState.DOMContentLoaded });
    }

    /// <summary>Activa una pestaña del listado estudiantil.</summary>
    public async Task SelectStudentCycleAsync(int cycle)
    {
        await page.GetByRole(AriaRole.Tab, new() { Name = $"{cycle}° Ciclo", Exact = true }).ClickAsync();
    }

    /// <summary>Abre la plana docente completa desde la escuela.</summary>
    public async Task OpenFacultyAsync()
    {
        await page.Locator("a[href$='ingenieria-sistemas/plana-docente']").ClickAsync();
        await page.WaitForURLAsync("**/ingenieria-sistemas/plana-docente", new() { WaitUntil = WaitUntilState.DOMContentLoaded });
    }

    /// <summary>Abre el directorio institucional enlazado al pie del portal.</summary>
    public async Task OpenDirectoryAsync()
    {
        await page.GetByRole(AriaRole.Link, new() { Name = "Directorio", Exact = true }).ClickAsync();
        await page.WaitForURLAsync("**/quienes-somos-upt/directorio", new() { WaitUntil = WaitUntilState.DOMContentLoaded });
    }
}


