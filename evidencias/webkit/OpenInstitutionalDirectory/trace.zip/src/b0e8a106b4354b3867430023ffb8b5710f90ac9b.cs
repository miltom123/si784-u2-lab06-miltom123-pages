using Microsoft.Playwright;
using Microsoft.Playwright.MSTest;
using UPTSite.Automation;
using System.Text.RegularExpressions;

[assembly: DoNotParallelize]
namespace UPTSiteTests;

[TestClass]
public class UPTSiteTest : PageTest
{
    private string evidenceDirectory = null!;
    private UptPortal portal = null!;

    public override BrowserNewContextOptions ContextOptions() => new()
    {
        ViewportSize = new() { Width = 1280, Height = 720 },
        RecordVideoDir = Path.Combine(EvidenceRoot, "videos"),
        RecordVideoSize = new() { Width = 1280, Height = 720 }
    };

    private static string EvidenceRoot => Environment.GetEnvironmentVariable("EVIDENCE_DIR")
        ?? Path.Combine(AppContext.BaseDirectory, "evidencias");

    [TestInitialize]
    public async Task StartEvidence()
    {
        evidenceDirectory = Path.Combine(EvidenceRoot, BrowserName, TestContext.TestName!);
        Directory.CreateDirectory(evidenceDirectory);
        Page.SetDefaultTimeout(30000);
        Page.SetDefaultNavigationTimeout(120000);
        portal = new UptPortal(Page);
        await Context.Tracing.StartAsync(new()
        {
            Title = $"{BrowserName} - {TestContext.TestName}",
            Screenshots = true,
            Snapshots = true,
            Sources = true
        });
    }

    [TestCleanup]
    public async Task SaveEvidence()
    {
        await Page.ScreenshotAsync(new() { Path = Path.Combine(evidenceDirectory, "resultado.png"), Animations = ScreenshotAnimations.Disabled });
        await File.WriteAllTextAsync(Path.Combine(evidenceDirectory, "pagina.txt"),
            $"URL {Page.Url}\nTítulo {await Page.TitleAsync()}\nResultado {TestContext.CurrentTestOutcome}\n" +
            await Page.Locator("body").InnerTextAsync());
        await Context.Tracing.StopAsync(new() { Path = Path.Combine(evidenceDirectory, "trace.zip") });
        var video = Page.Video;
        await Context.CloseAsync();
        await video!.SaveAsAsync(Path.Combine(evidenceDirectory, "video.webm"));
        TestContext.AddResultFile(Path.Combine(evidenceDirectory, "resultado.png"));
        TestContext.AddResultFile(Path.Combine(evidenceDirectory, "trace.zip"));
    }

    [TestMethod]
    public async Task HasTitle()
    {
        await portal.OpenHomeAsync();
        await Expect(Page).ToHaveTitleAsync(new Regex("UPT"));
        await Expect(Page.GetByRole(AriaRole.Button, new() { Name = "Pregrado", Exact = true })).ToBeVisibleAsync();
    }

    [TestMethod]
    public async Task GetSchoolDirectorName()
    {
        await portal.OpenHomeAsync();
        await portal.OpenSchoolAsync();
        var director = Page.GetByText("Dra. Haydee Raquel Sisa Yataco", new() { Exact = true });
        await director.ScrollIntoViewIfNeededAsync();
        await Expect(director).ToBeVisibleAsync();
        await Expect(Page.GetByText("Directora(e) de la Escuela Profesional de Ingeniería de Sistemas", new() { Exact = true })).ToBeVisibleAsync();
    }

    [TestMethod]
    public async Task SearchStudentInDirectoryPage()
    {
        await portal.OpenHomeAsync();
        await portal.OpenStudentsAsync();
        await portal.SelectStudentCycleAsync(2);
        var cycle = Page.Locator("#ciclo-2");
        await Expect(cycle).ToBeVisibleAsync();
        await Expect(cycle).ToHaveCSSAsync("opacity", "1");
        var student = cycle.Locator("li").Filter(new() { HasText = "Fiorella Gutiérrez Paz" });
        await Expect(student).ToContainTextAsync("20240121");
        await Expect(Page.Locator("#ciclo-1")).ToBeHiddenAsync();
    }

    [TestMethod]
    public async Task GetFacultyMember()
    {
        await portal.OpenHomeAsync();
        await portal.OpenSchoolAsync();
        await portal.OpenFacultyAsync();
        var teacher = Page.GetByText("Ing. Patrick Cuadros Quiroga", new() { Exact = true });
        await teacher.ScrollIntoViewIfNeededAsync();
        await Expect(teacher).ToBeVisibleAsync();
        var teacherCard = Page.Locator(".hover-card").Filter(new() { HasText = "Ing. Patrick Cuadros Quiroga" });
        await Expect(teacherCard).ToContainTextAsync("patcuadrosq@upt.pe");
    }

    [TestMethod]
    public async Task OpenInstitutionalDirectory()
    {
        await portal.OpenHomeAsync();
        await portal.OpenDirectoryAsync();
        var document = Page.Locator("iframe.pdf-iframe");
        await Expect(document).ToBeVisibleAsync();
        await Expect(document).ToHaveAttributeAsync("src", new Regex(@"^https://portal\.upt\.edu\.pe/management/uploads/.+\.pdf$"));
    }
}

